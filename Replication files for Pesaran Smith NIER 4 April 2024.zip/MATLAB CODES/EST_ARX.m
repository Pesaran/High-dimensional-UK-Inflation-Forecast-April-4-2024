function forecasts = EST_ARX(i, Y, window_size, h1, ahead, output)
% Estimating the forecasts of ARX model

if ahead == 1
    h = 0;
elseif ahead == 2
    h = 1;
elseif ahead == 4
    h = 3;
else
    disp("ERROR: You should provide an ahead value.")
end

X1 = lagmatrix(Y, h1);              % DPUK4(-h1)
X2 = lagmatrix(output.DDPUK4, h1);  % DDPUK4(-h1)
X3 = lagmatrix(output.DPSUK4, h1);  % DPSUK4(-h1)
X4 = lagmatrix(output.DDPSUK4, h1); % DDPSUK4(-h1)

Y_window  = Y(1:(i+window_size-1),:);

X1_window = X1(1:(i+window_size-1), :);
X2_window = X2(1:(i+window_size-1), :);
X3_window = X3(1:(i+window_size-1), :);
X4_window = X4(1:(i+window_size-1), :);

X_window  = [X1_window, X2_window, X3_window, X4_window];

X_window_with_constant = [ones(size(Y_window,1),1), X_window];

coef_window = regress(Y_window, X_window_with_constant);

forecasts = [1, Y((i+window_size-(h1-h)),:),...
    output.DDPUK4((i+window_size-(h1-h)),1),...
    output.DPSUK4((i+window_size-(h1-h)),1),...
    output.DDPSUK4((i+window_size-(h1-h)),1)]*coef_window;

end