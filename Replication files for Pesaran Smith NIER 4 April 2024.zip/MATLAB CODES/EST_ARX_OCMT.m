function [forecast, name_sel] =...
    EST_ARX_OCMT(i, Y, window_size, h1, ahead, output, delta)
% Estimating the forecasts of ARX OCMT model

if ahead == 1
    h = 0;
elseif ahead == 2
    h = 1;
elseif ahead == 4
    h = 3;
else
    disp("ERROR: You should provide an ahead value.")
end

pval   = 0.05;
delta1 = delta;
delta2 = 2;

[~, X_active_pc, ~, ~] = ACTIVE_SEL(output, h1, 'LASSO');

[Cond_Set, Active_Set, Active_Set_Orig, Names_Active] =...
        ACTIVE_SEL(output, h1, 'ARX-OCMT');

X_window_PC1 = X_active_pc(1:(i+window_size-1), :);
    
[~, PC1, ~] = pca(X_window_PC1, 'Centered', true, 'VariableWeights', 'variance', 'Algorithm', 'svd', 'NumComponents', 1);
    
Y_window               = Y(1:(i+window_size-1), :);
X_window               = [Cond_Set(1:(i+window_size-1),:), PC1];
X_window_with_constant = [ones(size(Y_window,1),1), X_window];
X_window_penal         = Active_Set(1:(i+window_size-1), :);

% AR2-OCMT
b_ocmt = ocmt_sel(Y_window, X_window_penal, X_window_with_constant, pval, delta1, delta2);
    
% Store names of selected variables
name_sel = Names_Active(b_ocmt');
    
% Refit the model with the selected variables and the unpenalized variables
X_selected = X_window_penal(:, b_ocmt');
X          = [ones(size(X_selected,1),1), Cond_Set(1:(i+window_size-1),:), X_selected];
b_selected = regress(Y_window, X);
    
X_sel_tab = array2table(Active_Set_Orig(:, b_ocmt'), 'VariableNames', name_sel);
    
if i+window_size <= 177
    
    X_forecast = array2table([Y(i+window_size-(h1-h),1),...
        output.DDPUK4(i+window_size-(h1-h),1),...
        output.DPSUK4(i+window_size-(h1-h),1),...
        output.DDPSUK4(i+window_size-(h1-h),1)]);
    
    for j = 1:size(X_sel_tab, 2)
        
        X_forecast = [X_forecast, X_sel_tab((i+window_size-(h1-h)),j)];

    end 
    
    X_forecast_fin = [1, table2array(X_forecast)];

    forecast = X_forecast_fin*b_selected;
    
end

end