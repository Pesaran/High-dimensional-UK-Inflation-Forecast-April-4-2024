function indUIT = ocmt_sel(Y, X, Xcond, pval, delta1, delta2)

[N, P] = size(X);
p_value1 = pval/(P^(delta1-1));

%% First Stage
ts           = zeros(P, 1);
ind          = false(P, 1);
t_threshold1 = norminv(1 - p_value1/2/P, 0, 1);
kappa        = zeros(P, 1);

for i = 1:P
    Xr         = [X(:,i), Xcond];
    [b, ~, e]  = regress(Y, Xr);
    e          = e(~isnan(e));
    nr         = size(Xr, 2);
    ve         = e'*e/(N-nr);
    nanRow     = any(isnan(Xr), 2);
    Xr         = Xr(~nanRow, :);
    App        = inv(Xr'*Xr);
    seb        = sqrt(App(1,1)*ve);
    ts(i, 1)   = abs(b(1))/seb;
    kappa(i,1) = abs(b(1))/(sqrt(0.5));
    ind(i,1)   = ts(i,1) > t_threshold1;
end

%% Multiple Stage
indUIT = ind;

%do_additional = true;
%no_boost      = 0;
%ind           = indUIT;
%p_value2      = pval/(P^(delta2-1));
%t_threshold2  = norminv(1 - p_value2/2/P, 0, 1); 
%itr           = 1;

%while do_additional
%    warning off
%
%    itr = itr + 1;
%    
%    if itr > 2
%        itr;
%    end
%    
%    ind0  = ind;
%    indb  = false(P,1);
%    kappa = zeros(P,1);
%    
%    for i = 1:P
%        if ind0(i,1) == 0
%            Xr         = [X(:,i), X(:,ind0), Xcond];
%            [b, ~, e]  = regress(Y, Xr);
%            e          = e(~isnan(e));
%            nanRow     = any(isnan(Xr), 2);
%            Xr         = Xr(~nanRow, :);
%            kr         = size(Xr, 2);
%            ve         = e'*e/(N-kr);
%            iXX        = inv(Xr'*Xr);
%            seb        = sqrt(iXX(1,1)*ve);
%            ts(i,1)    = abs(b(1))/seb;
%            kappa(i,1) = abs(b(1))/sqrt(ve);
%            indb(i,1)  = ts(i,1) > t_threshold2;
%        end
%    end
%
%    ind = ind0 | indb;
%    do_additional = sum(indb) > 0;
%    if do_additional
%        no_boost = no_boost + 1;
%    end
end
