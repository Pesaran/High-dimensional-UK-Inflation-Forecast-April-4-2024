function output = GENVARS(h1, data)

% (1) DPUK4=400*mav(DPUK,4);
eval('output.DPUK4 = data.DPUK4;')
eval(['output.DPUK4_lag' num2str(h1) ' = lagmatrix(data.DPUK4, h1);'])

% (2) DDPUK4=DPUK4-DPUK4(-1);
eval('output.DDPUK4 = data.DDPUK4;')
eval(['output.DDPUK4_lag' num2str(h1) ' = lagmatrix(data.DDPUK4, h1);'])

% (3) DYUK4=100*(YUK-YUK(-4));
eval('output.DYUK4 = data.DYUK4;')
eval(['output.DYUK4_lag' num2str(h1) ' = lagmatrix(data.DYUK4, h1);'])

% (4) DDYUK4=DYUK4-DYUK4(-1);
eval('output.DDYUK4 = data.DDYUK4;')
eval(['output.DDYUK4_lag' num2str(h1) ' = lagmatrix(data.DDYUK4, h1);'])

% (5) GAPUK8=100*(YUK-mav(YUK,8));
eval('output.GAPUK8 = data.GAPUK8;')
eval(['output.GAPUK8_lag' num2str(h1) ' = lagmatrix(data.GAPUK8, h1);'])

% (6) DGAPUK8=GAPUK8-GAPUK8(-1);
eval('output.DGAPUK8 = data.DGAPUK8;')
eval(['output.DGAPUK8_lag' num2str(h1) ' = lagmatrix(data.DGAPUK8, h1);'])

% (7) GAPUK12=100*(YUK-mav(YUK,12));
eval('output.GAPUK12 = data.GAPUK12;')
eval(['output.GAPUK12_lag' num2str(h1) ' = lagmatrix(data.GAPUK12, h1);'])

% (8) DGAPUK12=GAPUK12-GAPUK12(-1);
eval('output.DGAPUK12 = data.DGAPUK12;')
eval(['output.DGAPUK12_lag' num2str(h1) ' = lagmatrix(data.DGAPUK12, h1);'])

% (9) DEMUK4=100*(EMUK-EMUK(-4));
eval('output.DEMUK4 = data.DEMUK4;')
eval(['output.DEMUK4_lag' num2str(h1) ' = lagmatrix(data.DEMUK4, h1);'])

% (10) DDEMUK4=DEMUK4-DEMUK4(-1);
eval('output.DDEMUK4 = data.DDEMUK4;')
eval(['output.DDEMUK4_lag' num2str(h1) ' = lagmatrix(data.DDEMUK4, h1);'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (11) DVUK4=100*(vuk-vuk(-4));
eval('output.DVUK4 = data.DVUK4;')
eval(['output.DVUK4_lag' num2str(h1) ' = lagmatrix(data.DVUK4, h1);'])

% (12) DDVUK4=DVUK4-DVUK4(-1);
eval('output.DDVUK4 = data.DDVUK4;')
eval(['output.DDVUK4_lag' num2str(h1) ' = lagmatrix(data.DDVUK4, h1);'])

% (13) DUUK=UUK-UUK(-4);
eval('output.DUUK = data.DUUK;')
eval(['output.DUUK_lag' num2str(h1) ' = lagmatrix(data.DUUK, h1);'])

% (14) DDUUK=DUUK-DUUK(-1);
eval('output.DDUUK = data.DDUUK;')
eval(['output.DDUUK_lag' num2str(h1) ' = lagmatrix(data.DDUUK, h1);'])

% (15) DDWUK4=DWUK4-DWUK4(-1);
eval('output.DDWUK4 = data.DDWUK4;')
eval(['output.DDWUK4_lag' num2str(h1) ' = lagmatrix(data.DDWUK4, h1);'])

% (16) RUK4=400*mav(RUK,4);
eval('output.RUK4 = data.RUK4;')
eval(['output.RUK4_lag' num2str(h1) ' = lagmatrix(data.RUK4, h1);'])

% (17) DRUK4=RUK4-RUK4(-1);
eval('output.DRUK4 = data.DRUK4;')
eval(['output.DRUK4_lag' num2str(h1) ' = lagmatrix(data.DRUK4, h1);'])

% (18) LRUK4=400*mav(LRUK,4);
eval('output.LRUK4 = data.LRUK4;')
eval(['output.LRUK4_lag' num2str(h1) ' = lagmatrix(data.LRUK4, h1);'])

% (19) DLRUK4=LRUK4-LRUK4(-1);
eval('output.DLRUK4 = data.DLRUK4;')
eval(['output.DLRUK4_lag' num2str(h1) ' = lagmatrix(data.DLRUK4, h1);'])

% (20) DMUK4=100*(MUK-MUK(-4));
eval('output.DMUK4 = data.DMUK4;')
eval(['output.DMUK4_lag' num2str(h1) ' = lagmatrix(data.DMUK4, h1);'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (21) DDMUK4=DMUK4-DMUK4(-1);
eval('output.DDMUK4 = data.DDMUK4;')
eval(['output.DDMUK4_lag' num2str(h1) ' = lagmatrix(data.DDMUK4, h1);'])

% (22) DEQUK4=100*(EQUK-EQUK(-4));
eval('output.DEQUK4 = data.DEQUK4;')
eval(['output.DEQUK4_lag' num2str(h1) ' = lagmatrix(data.DEQUK4, h1);'])

% (23) DDEQUK4=DEQUK4-DEQUK4(-1);
eval('output.DDEQUK4 = data.DDEQUK4;')
eval(['output.DDEQUK4_lag' num2str(h1) ' = lagmatrix(data.DDEQUK4, h1);'])

% (24) DPOIL4=100*(POIL-POIL(-4));
eval('output.DPOIL4 = data.DPOIL4;')
eval(['output.DPOIL4_lag' num2str(h1) ' = lagmatrix(data.DPOIL4, h1);'])

% (25) DDPOIL4=DPOIL4-DPOIL4(-1); 
eval('output.DDPOIL4 = data.DDPOIL4;')
eval(['output.DDPOIL4_lag' num2str(h1) ' = lagmatrix(data.DDPOIL4, h1);'])

% (26) DPMAT4=100*(PMAT-PMAT(-4));
eval('output.DPMAT4 = data.DPMAT4;')
eval(['output.DPMAT4_lag' num2str(h1) ' = lagmatrix(data.DPMAT4, h1);'])

% (27) DDPMAT4=DPMAT4-DPMAT4(-1);
eval('output.DDPMAT4 = data.DDPMAT4;')
eval(['output.DDPMAT4_lag' num2str(h1) ' = lagmatrix(data.DDPMAT4, h1);'])

% (28) DPMETAL4=100*(PMETAL-PMETAL(-4));
eval('output.DPMETAL4 = data.DPMETAL4;')
eval(['output.DPMETAL4_lag' num2str(h1) ' = lagmatrix(data.DPMETAL4, h1);'])

% (29) DDPMETAL4=DPMETAL4-DPMETAL4(-1);
eval('output.DDPMETAL4 = data.DDPMETAL4;')
eval(['output.DDPMETAL4_lag' num2str(h1) ' = lagmatrix(data.DDPMETAL4, h1);'])

% (30) DPMUK4=100*(PMUK-PMUK(-4));
eval('output.DPMUK4 = data.DPMUK4;')
eval(['output.DPMUK4_lag' num2str(h1) ' = lagmatrix(data.DPMUK4, h1);'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (31) DDPMUK4=DPMUK4-DPMUK4(-1);
eval('output.DDPMUK4 = data.DDPMUK4;')
eval(['output.DDPMUK4_lag' num2str(h1) ' = lagmatrix(data.DDPMUK4, h1);'])

% (32) DEPUK4=100*(EPUK-EPUK(-4));
eval('output.DEPUK4 = data.DEPUK4;')
eval(['output.DEPUK4_lag' num2str(h1) ' = lagmatrix(data.DEPUK4, h1);'])

% (33) DDEPUK4=DEPUK4-DEPUK4(-1);
eval('output.DDEPUK4 = data.DDEPUK4;')
eval(['output.DDEPUK4_lag' num2str(h1) ' = lagmatrix(data.DDEPUK4, h1);'])

% (34) DPSUK4=400*mav(DPSUK,4); 
eval('output.DPSUK4 = data.DPSUK4;')
eval(['output.DPSUK4_lag' num2str(h1) ' = lagmatrix(data.DPSUK4, h1);'])

% (35) DDPSUK4=DPSUK4-DPSUK4(-1);
eval('output.DDPSUK4 = data.DDPSUK4;')
eval(['output.DDPSUK4_lag' num2str(h1) ' = lagmatrix(data.DDPSUK4, h1);'])

% (36) DYSUK4=100*(YSUK-YSUK(-4));
eval('output.DYSUK4 = data.DYSUK4;')
eval(['output.DYSUK4_lag' num2str(h1) ' = lagmatrix(data.DYSUK4, h1);'])

% (37) DDYSUK4=DYSUK4-DYSUK4(-1);
eval('output.DDYSUK4 = data.DDYSUK4;')
eval(['output.DDYSUK4_lag' num2str(h1) ' = lagmatrix(data.DDYSUK4, h1);'])

% (38) RUS4=400*mav(RUS,4);
eval('output.RUS4 = data.RUS4;')
eval(['output.RUS4_lag' num2str(h1) ' = lagmatrix(data.RUS4, h1);'])

% (39) DRUS4=RUS4-RUS4(-1);
eval('output.DRUS4 = data.DRUS4;')
eval(['output.DRUS4_lag' num2str(h1) ' = lagmatrix(data.DRUS4, h1);'])

% (40) LRUS4=400*mav(LRUS,4);
eval('output.LRUS4 = data.LRUS4;')
eval(['output.LRUS4_lag' num2str(h1) ' = lagmatrix(data.LRUS4, h1);'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (41) DLRUS4=LRUS4-LRUS4(-1);
eval('output.DLRUS4 = data.DLRUS4;')
eval(['output.DLRUS4_lag' num2str(h1) ' = lagmatrix(data.DLRUS4, h1);'])

% (42) DYCHINA4=100*(YCHINA-YCHINA(-4));
eval('output.DYCHINA4 = data.DYCHINA4;')
eval(['output.DYCHINA4_lag' num2str(h1) ' = lagmatrix(data.DYCHINA4, h1);'])

% (43) DDYCHINA4=DYCHINA4-DYCHINA4(-1);
eval('output.DDYCHINA4 = data.DDYCHINA4;')
eval(['output.DDYCHINA4_lag' num2str(h1) ' = lagmatrix(data.DDYCHINA4, h1);'])

% (44) GAPSUK8=100*(YSUK-mav(YSUK,8));
eval('output.GAPSUK8 = data.GAPSUK8;')
eval(['output.GAPSUK8_lag' num2str(h1) ' = lagmatrix(data.GAPSUK8, h1);'])

% (45) DGAPSUK8=GAPSUK8-GAPSUK8(-1);
eval('output.DGAPSUK8 = data.DGAPSUK8;')
eval(['output.DGAPSUK8_lag' num2str(h1) ' = lagmatrix(data.DGAPSUK8, h1);'])

% (46) GAPSUK12=100*(YSUK-mav(YSUK,12));
eval('output.GAPSUK12 = data.GAPSUK12;')
eval(['output.GAPSUK12_lag' num2str(h1) ' = lagmatrix(data.GAPSUK12, h1);'])

% (47) DGAPSUK12=GAPSUK12-GAPSUK12(-1);
eval('output.DGAPSUK12 = data.DGAPSUK12;')
eval(['output.DGAPSUK12_lag' num2str(h1) ' = lagmatrix(data.DGAPSUK12, h1);'])

% (48) DYUS4=100*(YUS-YUS(-4));
eval('output.DYUS4 = data.DYUS4;')
eval(['output.DYUS4_lag' num2str(h1) ' = lagmatrix(data.DYUS4, h1);'])

% (49) DDYUS4=DYUS4-DYUS4(-1);
eval('output.DDYUS4 = data.DDYUS4;')
eval(['output.DDYUS4_lag' num2str(h1) ' = lagmatrix(data.DDYUS4, h1);'])

% (50) DPUS4=400*mav(DPUS,4);
eval('output.DPUS4 = data.DPUS4;')
eval(['output.DPUS4_lag' num2str(h1) ' = lagmatrix(data.DPUS4, h1);'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (51) DDPUS4=DPUS4-DPUS4(-1);
eval('output.DDPUS4 = data.DDPUS4;')
eval(['output.DDPUS4_lag' num2str(h1) ' = lagmatrix(data.DDPUS4, h1);'])

% (52) DWUK4
eval('output.DWUK4 = data.DWUK4;')
eval(['output.DWUK4_lag' num2str(h1) ' = lagmatrix(data.DWUK4, h1);'])

disp('COMPLETED: ACTIVE SETS & CORRESPONDING VARIABLES ARE GENERATED.')

end