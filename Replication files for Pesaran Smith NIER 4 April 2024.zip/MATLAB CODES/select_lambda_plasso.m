function [idn, lambda] = select_lambda_plasso(X, y, lambdav)

% prediction-based selection

[nlam]      = size(lambdav,2);
T           = size(y,1);
ts          = T/10;
mse_lambdas = zeros(nlam,1);

for i=1:10 %10-fold cv

    inds = false(T,1);
    inds(floor((i-1)*ts+1):floor(i*ts),1) = true;
    valx = X(inds,:);
    valy = y(inds,1);
    trainx = X(not(inds),:);
    trainy = y(not(inds),1);
    
    % estimate over training sample
    [betamat] = pathl1_l(trainx, trainy, lambdav);
    
    % evaluate
    mse = mean((valy*ones(1, nlam) - valx*betamat').^2);
    mse_lambdas = mse_lambdas + mse'; % sum of MSEi
end

mse_lambdas = mse_lambdas./ 10; % CV(lambda)
[~, idn]    = min(mse_lambdas);
lambda      = lambdav(:, idn);

end
