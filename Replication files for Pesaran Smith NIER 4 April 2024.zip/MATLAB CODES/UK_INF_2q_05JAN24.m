%% UK Inflation Forecasteing 2q Ahead (Active Set)
% Last Update: Jan 05 2024
% Author: Hayun Song

% Model Specification:
% (1) AR2
% (2) ARX
% (3) LASSO (reported)
% (3.1) LASSO, (3.2) LASSO-AR2, (3.3) LASSO-ARX
% (4) LASSO with pooled MSE
% (4.1) LASSO, (4.2) LASSO-AR2, (4.3) LASSO-ARX
% (5) OCMT (delta = 1)
% (5.1) OCMT-AR2, (5.2) OCMT-ARX
% (6) OCMT (delta = 1.5)
% (6.1) OCMT-AR2, (6.2) OCMT-ARX

close all

clear

clc

%rng(12345, 'twister') % We do not need seed.

warning ('off', 'all');

%% Data Clearning and Variable Generation

h1 = 2;

ahead = 2;

window_size = 162;

data = load("ActiveSet_Data.mat").Data;

output = GENVARS(h1, data);

%% Memory Allocations

% DPUK4 (Dependent Variable; Y)
Y = data.DPUK4;

% Forecasts Memory Allocations
% (1) AR2 Model
AR2_forecast   = zeros(length(1:(length(Y)-window_size+1)), 1);

% (2) ARX Model
ARX_forecast   = zeros(length(1:(length(Y)-window_size+1)), 1);

% (3) LASSO with CPK_{AVE}
% (3.1) LASSO Model (LASSO_CKP_AVE)
LASSOave_forecast   = zeros(length(Y)-window_size+1, 1);
LASSOave_covariates = cell(length(Y)-window_size+1, 1);
LASSOave_var_names  = cell(1, length(Y)-window_size+1);
LASSOave_lam_sel    = zeros(length(Y)-window_size+1, 1);
% (3.2) AR2-LASSO Model (LASSO_CKP_AVE)
AR2_LASSOave_forecast   = zeros(length(Y)-window_size+1, 1);
AR2_LASSOave_covariates = cell(length(Y)-window_size+1, 1);
AR2_LASSOave_var_names  = cell(1, length(Y)-window_size+1);
AR2_LASSOave_lam_sel    = zeros(length(Y)-window_size+1, 1);
% (3.3) ARX-LASSO Model (LASSO_CKP_AVE)
ARX_LASSOave_forecast   = zeros(length(Y)-window_size+1, 1);
ARX_LASSOave_covariates = cell(length(Y)-window_size+1, 1);
ARX_LASSOave_var_names  = cell(1, length(Y)-window_size+1);
ARX_LASSOave_lam_sel    = zeros(length(Y)-window_size+1, 1);

% (4) LASSO with CPK_{POOL}
% (4.1) LASSO Model (LASSO_CKP_POOL)
LASSOpool_forecast   = zeros(length(Y)-window_size+1, 1);
LASSOpool_covariates = cell(length(Y)-window_size+1, 1);
LASSOpool_var_names  = cell(1, length(Y)-window_size+1);
LASSOpool_lam_sel    = zeros(length(Y)-window_size+1, 1);
% (4.2) AR2-LASSO Model (LASSO_CKP_POOL)
AR2_LASSOpool_forecast   = zeros(length(Y)-window_size+1, 1);
AR2_LASSOpool_covariates = cell(length(Y)-window_size+1, 1);
AR2_LASSOpool_var_names  = cell(1, length(Y)-window_size+1);
AR2_LASSOpool_lam_sel    = zeros(length(Y)-window_size+1, 1);
% (4.3) ARX-LASSO Model (LASSO_CKP_POOL)
ARX_LASSOpool_forecast   = zeros(length(Y)-window_size+1, 1);
ARX_LASSOpool_covariates = cell(length(Y)-window_size+1, 1);
ARX_LASSOpool_var_names  = cell(1, length(Y)-window_size+1);
ARX_LASSOpool_lam_sel    = zeros(length(Y)-window_size+1, 1);

% (5) OCMT (delta=1)
% (5) AR2-OCMT (delta=1)
AR2_OCMT1_forecast   = zeros(length(Y)-window_size+1, 1);
AR2_OCMT1_covariates = cell(length(Y)-window_size+1, 1);
AR2_OCMT1_var_names  = cell(1, length(Y)-window_size+1);
% (6) ARX-OCMT (delta=1)
ARX_OCMT1_forecast   = zeros(length(Y)-window_size+1, 1);
ARX_OCMT1_covariates = cell(length(Y)-window_size+1, 1);
ARX_OCMT1_var_names  = cell(1, length(Y)-window_size+1);

% (6) OCMT (delta=1.5)
% (6.1) AR2-OCMT (delta=1.5)
AR2_OCMT15_forecast   = zeros(length(Y)-window_size+1, 1);
AR2_OCMT15_covariates = cell(length(Y)-window_size+1, 1);
AR2_OCMT15_var_names  = cell(1, length(Y)-window_size+1);
% (6.2) ARX-OCMT (delta=1.5)
ARX_OCMT15_forecast   = zeros(length(Y)-window_size+1, 1);
ARX_OCMT15_covariates = cell(length(Y)-window_size+1, 1);
ARX_OCMT15_var_names  = cell(1, length(Y)-window_size+1);

disp('COMPLETED: MEMORY ALLOCATED.')

%% Loop with Expanding Windows

for i = 1:(length(Y)-window_size+1)
    
    % AR2 Model
    AR2_forecast(i,1) = EST_AR2(i, Y, window_size, h1, ahead, output);

    % ARX Model
    ARX_forecast(i,1) = EST_ARX(i, Y, window_size, h1, ahead, output);
    
    % LASSO Models with CPK_AVE
    [LASSOave_forecast(i), LASSOave_var_names{i},...
        lambda_grid_lasso, LASSOave_lam_sel(i)] =...
        EST_LASSO_AVE(i, Y, window_size, h1, ahead, output);
    
    % AR2-LASSO Models with CPK_AVE
    [AR2_LASSOave_forecast(i), AR2_LASSOave_var_names{i},...
        lambda_grid_ar2, AR2_LASSOave_lam_sel(i)] =...
        EST_AR2_LASSO_AVE(i, Y, window_size, h1, ahead, output);
    
    % ARX-LASSO Models with CPK_AVE
    [ARX_LASSOave_forecast(i), ARX_LASSOave_var_names{i},...
        lambda_grid_arx, ARX_LASSOave_lam_sel(i)] =...
        EST_ARX_LASSO_AVE(i, Y, window_size, h1, ahead, output);
    
    % LASSO Models with CPK_POOL
    [LASSOpool_forecast(i), LASSOpool_var_names{i},...
        lambda_grid_lasso_pool, LASSOpool_lam_sel(i)] =...
        EST_LASSO_POOL(i, Y, window_size, h1, ahead, output);

    % AR2-LASSO Models with CPK_POOL
    [AR2_LASSOpool_forecast(i), AR2_LASSOpool_var_names{i},...
        lambda_grid_ar2_pool, AR2_LASSOpool_lam_sel(i)] =...
        EST_AR2_LASSO_POOL(i, Y, window_size, h1, ahead, output);

    % ARX-LASSO Models with CPK_POOL
    [ARX_LASSOpool_forecast(i), ARX_LASSOpool_var_names{i},...
        lambda_grid_arx_pool, ARX_LASSOpool_lam_sel(i)] =...
        EST_ARX_LASSO_POOL(i, Y, window_size, h1, ahead, output);

    % OCMT (delta = 1)
    % AR2-OCMT
    [AR2_OCMT1_forecast(i), AR2_OCMT1_var_names{i}] =...
        EST_AR2_OCMT(i, Y, window_size, h1, ahead, output, 1);
    % ARX-OCMT
    [ARX_OCMT1_forecast(i), ARX_OCMT1_var_names{i}] =...
        EST_ARX_OCMT(i, Y, window_size, h1, ahead, output, 1);

    % OCMT (delta = 1.5)
    % AR2-OCMT
    [AR2_OCMT15_forecast(i), AR2_OCMT15_var_names{i}] =...
        EST_AR2_OCMT(i, Y, window_size, h1, ahead, output, 1.5);
    % ARX-OCMT
    [ARX_OCMT15_forecast(i), ARX_OCMT15_var_names{i}] =...
        EST_ARX_OCMT(i, Y, window_size, h1, ahead, output, 1.5);

end

disp('COMPLETED: ALL FORECASTS ARE GENERATED.')

%% Summarize Forecast Results and Plots

labels = {
    '2020q1', '2020q2', '2020q3', '2020q4',...
    '2021q1', '2021q2', '2021q3', '2021q4',...
    '2022q1', '2022q2', '2022q3', '2022q4',...
    '2023q1', '2023q2', '2023q3'};

x1 = 1:13;
x2 = 1:15;
y1 = Y(164:176,1);
% Benchmark Models
y2_AR2 = AR2_forecast;
y2_ARX = ARX_forecast;
% LASSO-based Models
y2_LASSOave  = LASSOave_forecast;
y2_LASSOpool = LASSOpool_forecast;
y2_AR2_LASSOave  = AR2_LASSOave_forecast;
y2_AR2_LASSOpool = AR2_LASSOpool_forecast;
y2_ARX_LASSOave  = ARX_LASSOave_forecast;
y2_ARX_LASSOpool = ARX_LASSOpool_forecast;
% OCMT-based Models
y2_AR2_OCMT1 = AR2_OCMT1_forecast;
y2_ARX_OCMT1 = ARX_OCMT1_forecast;
y2_AR2_OCMT15 = AR2_OCMT15_forecast;
y2_ARX_OCMT15 = ARX_OCMT15_forecast;

fig_all = figure;
plot(x1, y1,               'k', 'LineWidth', 2.5);
hold on;
plot(x2, y2_AR2_OCMT1,     '-r', 'LineWidth', 2.5);
plot(x2, y2_ARX_OCMT1,     '-b', 'LineWidth', 2.5);
plot(x2, y2_AR2_OCMT15,    '--*r', 'LineWidth', 2.5);
plot(x2, y2_ARX_OCMT15,    '--*b', 'LineWidth', 2.5);
plot(x2, y2_ARX_LASSOave,  ':c', 'LineWidth', 2.5);
plot(x2, y2_AR2_LASSOave,  ':g', 'LineWidth', 2.5);
plot(x2, y2_LASSOave,      'Color', [0.8500 0.3250 0.0980], 'LineStyle', ':', 'LineWidth', 2.5);
plot(x2, y2_ARX,           'Color', [1 0.8 0], 'LineStyle', '--', 'LineWidth', 2.5);
plot(x2, y2_AR2,           '--m', 'LineWidth', 2.5);
grid on
pos = get(fig_all, 'Position');
new_width = pos(3) * 2;
new_height = pos(4) * 2;
set(fig_all, 'Position', [0 0 new_width new_height]);
xticks(x2);
xticklabels(labels);
ax = gca;
ax.XAxis.FontSize = 10;
ax.YAxis.FontSize = 10;
ax.YAxis.Exponent = 0;
xlabel('Time Periods');
ylabel('Inflation Forecast');
hold off;
legend('dpuk4',...
    'AR2-OCMT (\delta = 1)', 'ARX-OCMT (\delta = 1)',...
    'AR2-OCMT (\delta = 1.5)', 'ARX-OCMT (\delta = 1.5)',...
    'ARX-LASSO', 'AR2-LASSO', 'LASSO',...
    'ARX', 'AR2', 'location', 'southeast')
legend('boxoff')

%% Save the Results

saveas(fig_all, 'UK_INF_2q_05JAN24.png');

result = [[y1;NaN;NaN], y2_AR2, y2_ARX,...
    y2_LASSOave, y2_AR2_LASSOave, y2_ARX_LASSOave,...
    y2_LASSOpool, y2_AR2_LASSOpool, y2_ARX_LASSOpool,...
    y2_AR2_OCMT1, y2_ARX_OCMT1, y2_AR2_OCMT15, y2_ARX_OCMT15];

RMSFE = sqrt(mean((result(1:13,2:end)-result(1:13,1)).^2));

ColNames = {'Actual', 'AR2', 'ARX',...
    'Lasso', 'Lasso-AR2', 'Lasso-ARX',...
    'Lasso-pooled-MSE', 'Lasso-AR2-pooled-MSE', 'Lasso-ARX-pooled-MSE',...
    'OCMT-AR2-d1', 'OCMT-ARX-d1', 'OCMT-AR2-d1.5', 'OCMT-ARX-d1.5'};

export_result = array2table(result, 'VariableNames', ColNames);

export_result.Properties.RowNames = {
    '2020Q1','2020Q2','2020Q3','2020Q4',...
    '2021Q1','2021Q2','2021Q3','2021Q4',...
    '2022Q1','2022Q2','2022Q3','2022Q4',...
    '2023Q1','2023Q2','2023Q3'};

writetable(export_result, 'UK_INF_FORECASTS_microfit_05JAN24.xls', 'Sheet', ...
    '2q Ahead')

export_excel = array2table([result; [NaN,RMSFE]], 'VariableNames', ColNames);

export_excel.Properties.RowNames = {
    '2020Q1','2020Q2','2020Q3','2020Q4',...
    '2021Q1','2021Q2','2021Q3','2021Q4',...
    '2022Q1','2022Q2','2022Q3','2022Q4',...
    '2023Q1','2023Q2','2023Q3','RMSFE'};

writetable(export_excel, 'UK_INF_FORECASTS_05JAN24.xls', 'Sheet', ...
    '2q Ahead', 'WriteRowNames', true);

disp('COMPLETED: ALL RESULTS ARE SAVED.')

save("UK_INF_2Q_RESULT_05JAN24.mat")

%% Regularization Parameters

VAR_SEL_LASSO_AVE      = zeros(length(Y)-window_size+1, 1);
VAR_SEL_AR2_LASSO_AVE  = zeros(length(Y)-window_size+1, 1);
VAR_SEL_ARX_LASSO_AVE  = zeros(length(Y)-window_size+1, 1);
VAR_SEL_LASSO_POOL     = zeros(length(Y)-window_size+1, 1);
VAR_SEL_AR2_LASSO_POOL = zeros(length(Y)-window_size+1, 1);
VAR_SEL_ARX_LASSO_POOL = zeros(length(Y)-window_size+1, 1);

VAR_SEL_AR2_OCMT1 = zeros(length(Y)-window_size+1, 1);
VAR_SEL_ARX_OCMT1 = zeros(length(Y)-window_size+1, 1);
VAR_SEL_AR2_OCMT15 = zeros(length(Y)-window_size+1, 1);
VAR_SEL_ARX_OCMT15 = zeros(length(Y)-window_size+1, 1);

for j = 1:(length(Y)-window_size+1)

    VAR_SEL_LASSO_AVE(j, 1) = length(LASSOave_var_names{j});
    VAR_SEL_AR2_LASSO_AVE(j, 1) = length(AR2_LASSOave_var_names{j});
    VAR_SEL_ARX_LASSO_AVE(j, 1) = length(ARX_LASSOave_var_names{j}); 

    VAR_SEL_LASSO_POOL(j, 1) = length(LASSOpool_var_names{j});
    VAR_SEL_AR2_LASSO_POOL(j, 1) = length(AR2_LASSOpool_var_names{j});
    VAR_SEL_ARX_LASSO_POOL(j, 1) = length(ARX_LASSOpool_var_names{j});

    VAR_SEL_AR2_OCMT1(j, 1) = length(AR2_OCMT1_var_names{j});
    VAR_SEL_ARX_OCMT1(j, 1) = length(ARX_OCMT1_var_names{j});
    VAR_SEL_AR2_OCMT15(j, 1) = length(AR2_OCMT15_var_names{j});
    VAR_SEL_ARX_OCMT15(j, 1) = length(ARX_OCMT15_var_names{j});

end

var_sel_excel = [
    VAR_SEL_LASSO_AVE, VAR_SEL_AR2_LASSO_AVE, VAR_SEL_ARX_LASSO_AVE,...
    LASSOave_lam_sel, AR2_LASSOave_lam_sel, ARX_LASSOave_lam_sel,...
    VAR_SEL_LASSO_POOL, VAR_SEL_AR2_LASSO_POOL, VAR_SEL_ARX_LASSO_POOL,...
    LASSOpool_lam_sel, AR2_LASSOpool_lam_sel, ARX_LASSOpool_lam_sel,...
    VAR_SEL_AR2_OCMT1, VAR_SEL_ARX_OCMT1,...
    VAR_SEL_AR2_OCMT15, VAR_SEL_ARX_OCMT15
    ];

ColNames = {'Lasso','Lasso-AR2', 'Lasso-ARX',...
    'Lasso-Lambda','Lasso-AR2-Lambda', 'Lasso-ARX-Lambda',...
    'Lasso-pooled-MSE','Lasso-AR2-pooled-MSE', 'Lasso-ARX-pooled-MSE',...
    'Lasso-pooled-MSE-Lambda','Lasso-AR2-pooled-MSE-Lambda', 'Lasso-ARX-pooled-MSE-Lambda',...
    'OCMT-AR2-d1', 'OCMT-ARX-d1', 'OCMT-AR2-d1.5', 'OCMT-ARX-d1.5'};

labels = {
    '2019q3', '2019q4', '2020q1', '2020q2',...
    '2020q3', '2020q4', '2021q1', '2021q2',...
    '2021q3', '2021q4', '2022q1', '2022q2',...
    '2022q3', '2022q4', '2023q1'};

var_sel_excel_output = array2table(var_sel_excel, 'VariableNames', ColNames, ...
    'RowNames', labels);

writetable(var_sel_excel_output, 'REG_PAR_NUM_SEL_LASSO_OCMT_05JAN24.xls',...
    'Sheet', '2q Ahead', 'WriteRowNames', true)

%% List of the Selected Variables

labels = {
    '2019q3', '2019q4', '2020q1', '2020q2',...
    '2020q3', '2020q4', '2021q1', '2021q2',...
    '2021q3', '2021q4', '2022q1', '2022q2',...
    '2022q3', '2022q4', '2023q1'};

for i = 1:length(LASSOave_var_names)
    
    % Cell-strings of the selected variables for each row i
    row_LASSOave = LASSOave_var_names{i};
    row_AR2_LASSOave = AR2_LASSOave_var_names{i};
    row_ARX_LASSOave = ARX_LASSOave_var_names{i};
    row_LASSOpool = LASSOpool_var_names{i};
    row_AR2_LASSOpool = AR2_LASSOpool_var_names{i};
    row_ARX_LASSOpool = ARX_LASSOpool_var_names{i};
    row_AR2_OCMT1 = AR2_OCMT1_var_names{i};
    row_ARX_OCMT1 = ARX_OCMT1_var_names{i};
    row_AR2_OCMT15 = AR2_OCMT15_var_names{i};
    row_ARX_OCMT15 = ARX_OCMT15_var_names{i};

    % Extract the strings in a row i cell
    r2w_LASSOave = row_LASSOave(:)';
    r2w_AR2_LASSOave = row_AR2_LASSOave(:)';
    r2w_ARX_LASSOave = row_ARX_LASSOave(:)';
    r2w_LASSOpool = row_LASSOpool(:)';
    r2w_AR2_LASSOpool = row_AR2_LASSOpool(:)';
    r2w_ARX_LASSOpool = row_ARX_LASSOpool(:)';
    r2w_AR2_OCMT1 = row_AR2_OCMT1(:)';
    r2w_ARX_OCMT1 = row_ARX_OCMT1(:)';
    r2w_AR2_OCMT15 = row_AR2_OCMT15(:)';
    r2w_ARX_OCMT15 = row_ARX_OCMT15(:)';

    % Add a date
    r2w_LASSOave = [{labels{i}}, r2w_LASSOave];
    r2w_AR2_LASSOave = [{labels{i}}, r2w_AR2_LASSOave];
    r2w_ARX_LASSOave = [{labels{i}}, r2w_ARX_LASSOave];
    r2w_LASSOpool = [{labels{i}}, r2w_LASSOpool];
    r2w_AR2_LASSOpool = [{labels{i}}, r2w_AR2_LASSOpool];
    r2w_ARX_LASSOpool = [{labels{i}}, r2w_ARX_LASSOpool];
    r2w_AR2_OCMT1 = [{labels{i}}, r2w_AR2_OCMT1];
    r2w_ARX_OCMT1 = [{labels{i}}, r2w_ARX_OCMT1];
    r2w_AR2_OCMT15 = [{labels{i}}, r2w_AR2_OCMT15];
    r2w_ARX_OCMT15 = [{labels{i}}, r2w_ARX_OCMT15];

    % Write the row to the Excel file in the corresponding row
    % Write the row to the Excel file in the corresponding row
    excelFileName = 'Selected_Variables_from_Active_Set_q2_Ahead_05JAN24.xls';
    
    writecell(r2w_LASSOave,      excelFileName, 'Sheet', 'Lasso', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_AR2_LASSOave,  excelFileName, 'Sheet', 'Lasso-AR2', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_ARX_LASSOave,  excelFileName, 'Sheet', 'Lasso-ARX', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_LASSOpool,     excelFileName, 'Sheet', 'Lasso-pooled', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_AR2_LASSOpool, excelFileName, 'Sheet', 'Lasso-AR2-pooled', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_ARX_LASSOpool, excelFileName, 'Sheet', 'Lasso-ARX-pooled', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_AR2_OCMT1,     excelFileName, 'Sheet', 'OCMT-AR2-d1', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_ARX_OCMT1,     excelFileName, 'Sheet', 'OCMT-ARX-d1', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_AR2_OCMT15,    excelFileName, 'Sheet', 'OCMT-AR2-d1.5', ...
        'Range', ['A' num2str(i)]);
    writecell(r2w_ARX_OCMT15,    excelFileName, 'Sheet', 'OCMT-ARX-d1.5', ...
        'Range', ['A' num2str(i)]);

end
