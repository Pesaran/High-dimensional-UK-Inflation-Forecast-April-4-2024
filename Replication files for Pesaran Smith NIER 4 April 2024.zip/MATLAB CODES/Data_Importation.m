%% Active Set Generation
% Generate "ActiveSet_Data.mat"
% Last Update: March 27, 2024
% Hayun Song

close all

clear

clc

warning ('off', 'all');

%% Import data from spreadsheet

opts = spreadsheetImportOptions("NumVariables", 78);

% Specify sheet and range
opts.Sheet = "j$";
opts.DataRange = "A3:BZ182";

% Specify column names and types
opts.VariableNames = ["Date", "INPT", "YUK", "DPUK", "EQUK", "EPUK", "RUK", "LRUK", "YSUK", "DPSUK", "EQSUK", "RSUK", "LRSUK", "POIL", "PMAT", "PMETAL", "YUS", "DPUS", "RUS", "LRUS", "YCHINA", "DWUK4", "UUK", "EMUK", "MUK", "VUK", "PMUK", "DPUK4", "DDPUK4", "DYUK4", "DDYUK4", "GAPUK8", "DGAPUK8", "GAPUK12", "DGAPUK12", "DEMUK4", "DDEMUK4", "DVUK4", "DDVUK4", "DUUK", "DDUUK", "DDWUK4", "RUK4", "DRUK4", "LRUK4", "DLRUK4", "DMUK4", "DDMUK4", "DEQUK4", "DDEQUK4", "DPOIL4", "DDPOIL4", "DPMAT4", "DDPMAT4", "DPMETAL4", "DDPMETAL4", "DPMUK4", "DDPMUK4", "DEPUK4", "DDEPUK4", "DPSUK4", "DDPSUK4", "DYSUK4", "DDYSUK4", "RUS4", "DRUS4", "LRUS4", "DLRUS4", "DYCHINA4", "DDYCHINA4", "GAPSUK8", "DGAPSUK8", "GAPSUK12", "DGAPSUK12", "DYUS4", "DDYUS4", "DPUS4", "DDPUS4"];
opts.VariableTypes = ["string", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double"];

% Specify variable properties
opts = setvaropts(opts, "Date", "WhitespaceRule", "preserve");
opts = setvaropts(opts, "Date", "EmptyFieldRule", "auto");

% Import the data
Active_Set = readtable("UK INFLATION PRIMARY DATA 1979Q2 2024Q1 - 12AUG23 ACTIVE SET.XLS", opts, "UseExcel", false);

clear opts

Data = Active_Set(1:176,:);
save("ActiveSet_Data.mat", "Data")
