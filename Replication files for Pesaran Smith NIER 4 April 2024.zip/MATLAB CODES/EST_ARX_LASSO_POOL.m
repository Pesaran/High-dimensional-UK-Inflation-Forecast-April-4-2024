function [forecast, name_sel, lambda_grid, lam_sel] =...
    EST_ARX_LASSO_POOL(i, Y, window_size, h1, ahead, output)

if ahead == 1
    h = 0;
elseif ahead == 2
    h = 1;
elseif ahead == 4
    h = 3;
else
    disp("ERROR: You should provide an ahead value.")
end

[Cond_Set, Active_Set, Active_Set_Orig, Names_Active] =...
        ACTIVE_SEL(output, h1, 'ARX-LASSO');

% Select data for this window
Y_window       = Y(1:(i+window_size-1), :);

% Fit the penalized predictors with Lasso for feature selection
X_window = [Cond_Set(1:(i+window_size-1),:)];
X_window_with_constant = [ones(size(Y_window,1),1), X_window];

[b, ~, r1] = regress(Y_window, X_window_with_constant);

r_sets_ar2_lasso = zeros(length(Y_window), size(Active_Set,2));

X_active_ar2_lasso_window = Active_Set(1:(i+window_size-1),:);

for j = 1:size(X_active_ar2_lasso_window, 2)
    X_sel = X_active_ar2_lasso_window(:,j);
    [b_ar2_glasso, ~, r_ar2_glasso] = regress(X_sel, X_window_with_constant);
    r_sets_ar2_lasso(:,j) = r_ar2_glasso;
end

nan_rows = any(isnan(r_sets_ar2_lasso), 2) | isnan(r1);
X_no_nan = r_sets_ar2_lasso(~nan_rows, :);
y_no_nan = r1(~nan_rows);

[var_sel, lam_sel, lambda_grid] = pLasso_fsel(y_no_nan, X_no_nan);
name_sel = Names_Active(logical(var_sel')); 

% Refit the model with the selected variables and the unpenalized variables
X_selected = X_active_ar2_lasso_window(:, logical(var_sel'));
b_selected = regress(Y_window, [X_window_with_constant, X_selected]);
    
X_sel_tab = array2table(Active_Set_Orig(:, logical(var_sel')), 'VariableNames', name_sel);

% Forecast the next value outside the window
if i+window_size <= 177

    X_forecast = array2table([Y(i+window_size-(h1-h),1),...
        output.DDPUK4(i+window_size-(h1-h),1),...
        output.DPSUK4(i+window_size-(h1-h),1),...
        output.DDPSUK4(i+window_size-(h1-h),1)]);

    for j = 1:size(X_sel_tab,2)

        X_forecast = [X_forecast, X_sel_tab((i+window_size-(h1-h)),j)];

    end

    X_forecast_fin = [1, table2array(X_forecast)];

    forecast = X_forecast_fin*b_selected;

end

end