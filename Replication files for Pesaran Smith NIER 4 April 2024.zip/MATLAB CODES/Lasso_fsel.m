function [sellasso, lambda, lambdav] = Lasso_fsel(y,X,varset)

if (nargin < 3) varset = []; end

T               = size(y,1);
muy             = y'*ones(T,1)/T;
ydm             = y-muy;
    
%de-mean and standardize x
mux                 = ones(1,T)*X/T;
Xdm                 = X-ones(T,1)*mux;
stdX                = diag(Xdm'*Xdm/(T)).^0.5;
Xstd                = Xdm./(ones(T,1)*stdX');

[betap,lambdav,~,~,~] = pathl1(Xstd, ydm, varset);
[id, lambda]          = select_lambda_lasso(Xstd, ydm, lambdav);
beta                  = betap(id,:)';
ind                   = not(beta == 0);
sellasso              = zeros(size(beta,1),1);
sellasso(ind)         = 1;

end