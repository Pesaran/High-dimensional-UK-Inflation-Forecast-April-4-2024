function forecasts = EST_AR2(i, Y, window_size, h1, ahead, output)
% Estimating the forecasts of AR2 model

if ahead == 1
    h = 0;
elseif ahead == 2
    h = 1;
elseif ahead == 4
    h = 3;
else
    disp("ERROR: You should provide an ahead value.")
end

Y_window = Y(1:(i+window_size-1), :);

X1        = lagmatrix(Y, h1);
X1_window = X1(1:(i+window_size-1), :);

X2        = lagmatrix(output.DDPUK4, h1);
X2_window = X2(1:(i+window_size-1), :);

X_window_with_constant = [ones(size(Y_window,1),1), X1_window, X2_window];

coef_window = regress(Y_window, X_window_with_constant);

forecasts = [1, Y((i+window_size-(h1-h)),1), output.DDPUK4((i+window_size-(h1-h)),1)]*coef_window;

end