function [forecast, name_sel, lambda_grid, lam_sel] =...
    EST_LASSO_AVE(i, Y, window_size, h1, ahead, output)
% Estimating the forecasts of LASSO Average model

if ahead == 1
    h = 0;
elseif ahead == 2
    h = 1;
elseif ahead == 4
    h = 3;
else
    disp("ERROR: You should provide an ahead value.")
end

[~, Active_Set, Active_Set_Orig, Names_Active] = ACTIVE_SEL(output, h1, 'LASSO');

% Dependent Variable
Y_window = Y(1:(i+window_size-1), :);

% Fit the penalized predictors with Lasso for feature selection
X_window_active = Active_Set(1:(i+window_size-1), :);

nan_rows = any(isnan(X_window_active), 2) | isnan(Y_window);
X_no_nan = X_window_active(~nan_rows, :);
y_no_nan = Y_window(~nan_rows);

[var_sel, lam_sel, lambda_grid] = Lasso_fsel(y_no_nan, X_no_nan);
name_sel = Names_Active(logical(var_sel')); 

% Refit the model with the selected variables and the unpenalized variables
X_selected = X_window_active(:, logical(var_sel'));
b_selected = regress(Y_window, [ones(size(Y_window,1),1), X_selected]);
    
X_sel_tab = array2table(Active_Set_Orig(:, logical(var_sel')), 'VariableNames', name_sel);

% Forecast the next value outside the window
if i+window_size <= 177

    X_forecast = [];

    for j = 1:size(X_sel_tab,2)

        X_forecast = [X_forecast, X_sel_tab((i+window_size-(h1-h)),j)];

    end

    X_forecast_fin = [1, table2array(X_forecast)];
    
    forecast = X_forecast_fin*b_selected;
    
end

end